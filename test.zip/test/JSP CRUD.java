CREATE DATABASE jsp_crud_db;
USE jsp_crud_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL
);

// INDEX JSP

<%@ page import="java.sql.*" %>
<html>
<head><title>Users List</title></head>
<body>
<h2>All Users</h2>
<a href="addUser.jsp">Add New User</a><br/><br/>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Country</th><th>Actions</th></tr>

<%
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_crud_db","root","your_password");
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT * FROM users");

    while(rs.next()){
%>
<tr>
    <td><%= rs.getInt("id") %></td>
    <td><%= rs.getString("name") %></td>
    <td><%= rs.getString("email") %></td>
    <td><%= rs.getString("country") %></td>
    <td>
        <a href="editUser.jsp?id=<%= rs.getInt("id") %>">Edit</a> | 
        <a href="deleteUser.jsp?id=<%= rs.getInt("id") %>">Delete</a>
    </td>
</tr>
<% } rs.close(); con.close(); %>

</table>
</body>
</html>


// addUser.jsp – Insert New User

<%@ page import="java.sql.*" %>
<%
if(request.getMethod().equalsIgnoreCase("POST")){
    String name = request.getParameter("name");
    String email = request.getParameter("email");
    String country = request.getParameter("country");

    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_crud_db","root","your_password");
    PreparedStatement ps = con.prepareStatement("INSERT INTO users(name,email,country) VALUES(?,?,?)");
    ps.setString(1,name);
    ps.setString(2,email);
    ps.setString(3,country);
    ps.executeUpdate();
    con.close();
    response.sendRedirect("index.jsp");
}
%>
<html>
<head><title>Add User</title></head>
<body>
<h2>Add New User</h2>
<form method="post">
    Name: <input type="text" name="name"/><br/>
    Email: <input type="text" name="email"/><br/>
    Country: <input type="text" name="country"/><br/>
    <input type="submit" value="Add User"/>
</form>
<a href="index.jsp">Back to List</a>
</body>
</html>

// editUser.jsp – Update User

<%@ page import="java.sql.*" %>
<%
String id = request.getParameter("id");
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_crud_db","root","your_password");

if(request.getMethod().equalsIgnoreCase("POST")){
    String name = request.getParameter("name");
    String email = request.getParameter("email");
    String country = request.getParameter("country");

    PreparedStatement ps = con.prepareStatement("UPDATE users SET name=?, email=?, country=? WHERE id=?");
    ps.setString(1,name);
    ps.setString(2,email);
    ps.setString(3,country);
    ps.setInt(4,Integer.parseInt(id));
    ps.executeUpdate();
    con.close();
    response.sendRedirect("index.jsp");
} else {
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT * FROM users WHERE id="+id);
    rs.next();
%>
<html>
<head><title>Edit User</title></head>
<body>
<h2>Edit User</h2>
<form method="post">
    Name: <input type="text" name="name" value="<%= rs.getString("name") %>"/><br/>
    Email: <input type="text" name="email" value="<%= rs.getString("email") %>"/><br/>
    Country: <input type="text" name="country" value="<%= rs.getString("country") %>"/><br/>
    <input type="submit" value="Update User"/>
</form>
<a href="index.jsp">Back to List</a>
</body>
</html>
<% rs.close(); con.close(); } %>

//  deleteUser.jsp – Delete User

<%@ page import="java.sql.*" %>
<%
String id = request.getParameter("id");
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_crud_db","root","your_password");

PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE id=?");
ps.setInt(1,Integer.parseInt(id));
ps.executeUpdate();
con.close();

response.sendRedirect("index.jsp");
%>
